\**
  *********************************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WL3xx devices support on EWARM.
  **********************************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *********************************************************************************************************************************/
  
  Package general purpose:
  ===================================================================================================================================	
    These packages contains the needed files to be installed in order to support STM32WL3xx devices by EWARM9 and laters.

    We inform you that this package is suitable for internal & external use.
	EWARMv9_STM32WL3xx_V1.3.0-RC1.exe has been digitally signed by STMicroelectronics.

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  =================================================================================================================================== 
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	
	2. The following items will be added :
    - Product line with 256KB Flash size:STM32WL33xC/STM32WL3MxC.
	- Product line with 128KB Flash size:STM32WL33xB/WL30xB/WL31xB/WL3RxB.
	- Product line with 64KB Flash size:STM32WL33x8/WL30x8/WL31x8/WL3Rx8.
	- Automatic flashloader algorithm selection.
	
	3. The following SVD files will be added:
	- STM32WL33, STM32WL30 & STM32WL31 SVD files v1r1.
	  STM32WL3R SVD file v0r1.
  

PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
    That you can run EWARMv9_STM32WL3xx_V1.3.0-RC1.exe only if the uninstall is not needed.

 How to use:
 ====================================================================================================================================
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32WL3xx_V1.3.0-RC1.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   
	
 SVD files ReleaseNotes:
 ========================================================================================================================================
	=======================================================
	STM32WL3x_v1r1:     Official release
	=======================================================
	V1.0   First release with support for STM32WL33
	V1.1   Adding support for STM32WL30 and STM32WL31

	=======================================================
	STM32WL3R_v0r1:     initial release
	=======================================================
	Release based on available IPxact and CPN list under project SharePoint.
	w/o: COMP/DAC/LCSC/LCD/I2C2/SPI1